const {
  register,
  login,
  signOut,
  verifytoken,
  forgotPassword,
  resetPassword,
  test,
  postData,
  getProfileData,
  getAllUsers,
} = require('../Controllers/AuthControllers')
const {checkUser} = require('../Middlewares/AuthMiddlewares')

const router = require('express').Router()

router.get('/logout', signOut)
router.post('/create/user', register)
router.post('/login', login)
router.get('/verify/token', verifytoken)
router.post('/forgot_password', forgotPassword)
router.post('/', getAllUsers)

// router.post("/", checkUser);
// router.post("/getdata", getProfileData);
// router.post("/test", test);
// router.post("/resetpassword", resetPassword);
// router.post("/postdata", postData);

module.exports = router
