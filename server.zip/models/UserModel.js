const mongoose = require('mongoose')
const bcrypt = require('bcrypt')

const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: [true, 'username is required'],
    unique: true,
  },
  email: {
    type: String,
    required: [true, 'Email is required'],
    unique: true,
  },
  user_pass: {
    type: String,
    required: [true, 'Password is required'],
  },
  user_login: {
    type: String,
    required: [true, 'Username is required'],
  },
  first_name: {
    type: String,
    required: [true, 'Firstname is required'],
  },
  last_name: {
    type: String,
    required: [false, 'Lastname is Optional'],
  },
})

userSchema.pre('save', async function (next) {
  const salt = await bcrypt.genSalt()
  this.user_pass = await bcrypt.hash(this.user_pass, salt)
  next()
})

userSchema.statics.login = async function (email, password) {
  console.log(email)
  const user = await this.findOne({email})
  console.log(user)

  if (user) {
    const auth = await bcrypt.compare(password, user.user_pass)
    if (auth) {
      return user
    }
    throw Error('Incorrect password')
  }
  throw Error('Incorrect Email')
}

module.exports = mongoose.model('User', userSchema)
