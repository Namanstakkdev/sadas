const db = require('./models')
const {
  userControllers,
  productControllers,
  categoryControllers,
} = require('./controllers/dash.controller')

db.sequelize
  .sync()
  .then(() => {
    console.log('As you were offline your db has been Synced.')
  })
  .catch((err) => {
    console.log('Failed to sync db: ' + err.message)
  })

// drop the table if it already exists

// db.sequelize.sync({force: true}).then(() => {
//   console.log('Drop and re-sync db.')
// })

module.exports = {
  userControllers,
  productControllers,
  categoryControllers,
}
